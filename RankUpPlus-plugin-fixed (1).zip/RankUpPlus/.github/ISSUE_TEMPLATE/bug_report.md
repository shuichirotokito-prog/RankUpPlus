---
name: Bug report
about: Something isn't working right
title: ''
labels: bug
assignees: ''
---

**Server software and version** (e.g. Paper 1.21.8, Spigot 1.21.4):

**Plugin version**:

**Other plugins installed that might be relevant** (Vault, LuckPerms, PlaceholderAPI, economy plugin, etc.):

**What happened**:

**What you expected to happen**:

**Console error / stack trace** (if any — please paste the full trace, not just the first line):

```
paste here
```

**Steps to reproduce**:
1.
2.
3.
